library(testthat)
library(geex)

test_check("geex")
